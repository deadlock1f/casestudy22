package com.cg.querymanagement.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.querymanagement.beans.Query_master;
import com.cg.querymanagement.repo.IQueryDAO;
@Component(value = "queryServices")
public class QueryServiceImpl implements IQueryService{

	@Autowired(required=true)
	IQueryDAO repo;

	@Override
	public Query_master solutionsToQuery(Query_master queryManagement) {
		return repo.save(queryManagement);
	}

	@Override
	public Query_master getQueryById(int id) {
		Query_master queryMaster = repo.findOne(id);
		if(queryMaster == null)
			throw new NullPointerException("Query not Found, wrong query id " + id);
		return queryMaster;
	}
}
