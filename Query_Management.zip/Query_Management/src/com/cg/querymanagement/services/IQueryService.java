package com.cg.querymanagement.services;

import java.util.List;

import com.cg.querymanagement.beans.Query_master;

public interface IQueryService {
	public Query_master solutionsToQuery(Query_master queryManagement);
	public Query_master getQueryById(int id);
}
