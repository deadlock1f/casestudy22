package com.cg.querymanagement.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.cg.querymanagement.beans.Query_master;
import com.cg.querymanagement.services.IQueryService;


@Controller
public class queryController {
	@Autowired
	IQueryService queryServices;
	
	@RequestMapping(value="/")
	public String getQuery() {
		return "queryPage";
	}
	
	@RequestMapping(value="getDetails")
	public ModelAndView getDetails(@RequestParam("queryId") int id) {
		try {
			Query_master queryManagement = queryServices.getQueryById(id);
			return new ModelAndView("queryDetailsSuccess","querydetails",queryManagement);
		}
		catch(NullPointerException e) {
			return new ModelAndView("error","errorPage",e.getMessage());
		}
		
	}
	
	@RequestMapping(value="updateQuery/{id}",method = RequestMethod.GET)
	public ModelAndView updateDetails(@PathVariable int id) {
		return new ModelAndView("UpdateSuccess","query",id);
	}
	
}
