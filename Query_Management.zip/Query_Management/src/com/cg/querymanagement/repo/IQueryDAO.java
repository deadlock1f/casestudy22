package com.cg.querymanagement.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.querymanagement.beans.Query_master;

public interface IQueryDAO extends JpaRepository<Query_master, Integer>{

}
